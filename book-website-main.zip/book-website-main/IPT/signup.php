<?php
// filepath: c:\xampp\htdocs\EnrollmentCollege\signup.php
$conn = new mysqli("localhost", "root", "", "your_database_name");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['signup'])) {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('Email already registered!');window.location.href='signup.html';</script>";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $password);
        if ($stmt->execute()) {
            echo "<script>alert('Sign up successful! Please log in.');window.location.href='login.html';</script>";
        } else {
            echo "<script>alert('Error: Could not sign up.');window.location.href='signup.html';</script>";
        }
        $stmt->close();
    }
    $check->close();
}
$conn->close();
?>