<?php
session_start();
$conn = new mysqli("localhost", "root", "", "bookwebsite");

// Get book id from URL
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Log as recently read if user is logged in
if (isset($_SESSION['user_id']) && $book_id > 0) {
    $user_id = intval($_SESSION['user_id']);
    // Optional: Remove previous entry for this book/user to avoid duplicates
    $conn->query("DELETE FROM recently_read WHERE user_id=$user_id AND book_id=$book_id");
    // Insert new entry
    $conn->query("INSERT INTO recently_read (user_id, book_id, read_at) VALUES ($user_id, $book_id, NOW())");
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Handle favorite action
if (isset($_POST['favorite_book_id']) && isset($_SESSION['id'])) {
    $userId = intval($_SESSION['id']);
    $favBookId = intval($_POST['favorite_book_id']);
    $conn->query("INSERT IGNORE INTO favorites (user_id, book_id) VALUES ($userId, $favBookId)");
}

// Handle continue reading action
if (isset($_POST['continue_book_id']) && isset($_SESSION['id'])) {
    $userId = intval($_SESSION['id']);
    $contBookId = intval($_POST['continue_book_id']);
    $conn->query("REPLACE INTO continue_reading (user_id, book_id, last_accessed) VALUES ($userId, $contBookId, NOW())");
}

// Handle most read action
if (isset($_POST['read_book_id']) && isset($_SESSION['id'])) {
    $userId = intval($_SESSION['id']);
    $readBookId = intval($_POST['read_book_id']);
    $conn->query("INSERT INTO most_read (user_id, book_id, read_at) VALUES ($userId, $readBookId, NOW())");
}

$result = $conn->query("SELECT * FROM books WHERE id=$id");
$book = $result->fetch_assoc();
if (!$book) {
    echo "Book not found.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($book['title']); ?> - Book Details</title>
    <link rel="stylesheet" href="hehe.css">
    <style>
      body {
        transition: opacity 0.5s;
      }
      body.fade-out {
        opacity: 0;
      }
      .fav-btn, .cont-btn, .read-btn {
        border: none;
        background: none;
        font-size: 1.3em;
        cursor: pointer;
        margin-right: 10px;
        transition: transform 0.1s;
      }
      .fav-btn:hover { color: #e25555; transform: scale(1.2);}
      .cont-btn:hover, .read-btn:hover { color: #9c6b3e; transform: scale(1.1);}
    </style>
</head>
<body>
    <header class="header">
        <div style="text-align:right; max-width:1200px; margin:0 auto;">
            <form action="1.php" method="get" style="display:inline;">
                <button type="submit" style="margin:12px 0 0 0; padding:8px 22px; border-radius:12px; border:none; background:#9c6b3e; color:#fff; font-weight:bold; font-size:1em; cursor:pointer;">
                    Back to Home
                </button>
            </form>
        </div>
    </header>
    <div class="container">
        <aside class="sidebar">
            <!-- ...your sidebar code... -->
        </aside>
        <main class="main-content">
            <div class="content-wrapper">
                <div class="book-description">
                    <h1><?php echo htmlspecialchars($book['title']); ?></h1>
                    <h3><?php echo htmlspecialchars($book['author']); ?></h3>
                    <br>
                    <p><?php echo nl2br(htmlspecialchars($book['description'])); ?></p>
                    <?php if (isset($_SESSION['id'])): ?>
                        <div style="margin-top:18px;">
                            <form method="post" action="book.php?id=<?php echo $book['id']; ?>" style="display:inline;">
                                <input type="hidden" name="favorite_book_id" value="<?php echo $book['id']; ?>">
                                <button type="submit" class="fav-btn" title="Add to Favorites">❤️</button>
                            </form>
                            <form method="post" action="book.php?id=<?php echo $book['id']; ?>" style="display:inline;">
                                <input type="hidden" name="continue_book_id" value="<?php echo $book['id']; ?>">
                                <button type="submit" class="cont-btn" title="Add to Continue Reading">📖</button>
                            </form>
                            <form method="post" action="book.php?id=<?php echo $book['id']; ?>" style="display:inline;">
                                <input type="hidden" name="read_book_id" value="<?php echo $book['id']; ?>">
                                <button type="submit" class="read-btn" title="Mark as Most Read">🔥</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="book-image">
                    <img src="<?php echo htmlspecialchars($book['cover']); ?>" alt="Book Cover" />
                </div>
            </div>
        </main>
    </div>
    <script>
document.querySelectorAll('a').forEach(function(link) {
  // Only apply to internal links
  if (link.hostname === window.location.hostname && link.target !== "_blank" && !link.href.startsWith('javascript:')) {
    link.addEventListener('click', function(e) {
      // Ignore anchor links
      if (link.hash && link.pathname === window.location.pathname) return;
      e.preventDefault();
      document.body.classList.add('fade-out');
      setTimeout(function() {
        window.location = link.href;
      }, 500); // Match the CSS transition duration
    });
  }
});
</script>
</body>
</html>