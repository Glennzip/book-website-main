<?php
<?php
header("Location: user.html");
exit();
?>